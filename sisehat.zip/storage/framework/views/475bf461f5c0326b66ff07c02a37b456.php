<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SiSehat - Daftar Karyawan</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        /* Reset & Base */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { display: flex; height: 100vh; background-color: #f4f7f6; overflow: hidden; }

        /* ================= SIDEBAR ================= */
        .sidebar {
            width: 280px; background-color: #ffffff; border-right: 1px solid #f1f5f9;
            display: flex; flex-direction: column; padding: 25px 15px; flex-shrink: 0; z-index: 10;
        }
        .logo-box { display: flex; justify-content: center; align-items: center; margin-bottom: 25px; width: 100%; }
        .logo-main { width: 150px; height: auto; display: block; }

        .btn-primary-custom {
            background-color: #0a4ebd; color: white; border: none; padding: 12px; border-radius: 8px;
            cursor: pointer; font-weight: 700; font-size: 13px; margin-bottom: 20px; width: 100%; transition: 0.3s;
            display: flex; align-items: center; justify-content: center; gap: 8px;
        }
        .btn-primary-custom:hover { background-color: #083ba1; transform: translateY(-1px); }
                .sidebar-divider { border: none; border-top: 1.5px solid #e5e7eb; margin-top: 10px; margin-bottom: 15px; width: 100%; }

        .nav-list { list-style: none; flex-grow: 1; margin-top: 10px; }
        .nav-item { 
            display: flex; align-items: center; gap: 12px; padding: 12px 15px; 
            margin-bottom: 8px; border-radius: 10px; cursor: pointer; 
            color: #718096; transition: all 0.3s ease; 
            font-weight: 500;
        }
        .nav-icon {
            width: 20px; height: 20px; object-fit: contain;
            filter: grayscale(100%); opacity: 0.6; transition: 0.3s;
        }
        .nav-item span { font-size: 14px; line-height: normal; }
        
        .nav-item.active { 
            background-color: #eef2ff; 
            color: #1d4ed8; 
            font-weight: 700;
        }
        .nav-item.active .nav-icon { 
            filter: none; 
            opacity: 1; 
            filter: brightness(0) saturate(100%) invert(26%) sepia(89%) saturate(1966%) hue-rotate(211deg) brightness(97%) contrast(101%);
        }
        
        .nav-item:hover:not(.active) { background-color: #f8fafc; color: #1e293b; }
        .nav-item:hover .nav-icon { opacity: 0.9; filter: grayscale(0%); }

        .profile-card { 
            margin-top: auto; 
            padding: 12px 15px; 
            background-color: #eef2ff; 
            border-radius: 12px; 
            display: flex; 
            align-items: center; 
            gap: 12px;
            cursor: pointer;
            transition: 0.3s;
        }
        .profile-card:hover { background-color: #e0e7ff; }
        .avatar-sidebar { width: 45px; height: 45px; border-radius: 50%; background-color: #0a4ebd; color: white; display: flex; align-items: center; justify-content: center; font-weight: bold; overflow: hidden; }
        .avatar-sidebar img { width: 100%; height: 100%; object-fit: cover; }
        .profile-info { flex-grow: 1; text-align: right; }
        .profile-info h4 { font-size: 15px; color: #1e293b; font-weight: 800; line-height: 1.2; }
        .profile-info p { font-size: 11px; color: #64748b; font-weight: 600; }

        /* ================= MAIN CONTENT ================= */
        .content-area { flex-grow: 1; padding: 40px; overflow-y: auto; scroll-behavior: smooth; }
        
        .page-header-flex { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .page-header h1 { font-size: 26px; color: #1e293b; font-weight: 800; margin-bottom: 8px; }
        .page-header p { color: #64748b; font-size: 14px; line-height: 1.5; }
        
        .btn-add-karyawan {
            background-color: #2563eb; color: white; border: none; padding: 12px 20px; 
            border-radius: 8px; font-weight: 600; font-size: 14px; cursor: pointer; transition: 0.2s;
            box-shadow: 0 2px 4px rgba(37, 99, 235, 0.2); display: flex; align-items: center; gap: 8px; text-decoration: none;
        }
        .btn-add-karyawan:hover { background-color: #1d4ed8; }

        /* ================= TABLE CARD ================= */
        .table-card {
            background-color: #ffffff;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.03);
            border: 1px solid #f1f5f9;
        }

        .data-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .data-table th { 
            background-color: #f8fafc; color: #475569; font-size: 12px; font-weight: 700; 
            text-align: left; padding: 15px; border-radius: 4px;
        }
        .data-table td { padding: 15px; border-bottom: 1px solid #e2e8f0; font-size: 14px; color: #1e293b; font-weight: 500; vertical-align: middle; }
        .data-table tr:last-child td { border-bottom: none; }

        .karyawan-name-cell { display: flex; align-items: center; gap: 12px; }
        .karyawan-avatar { 
            width: 32px; height: 32px; border-radius: 50%; display: flex; justify-content: center; align-items: center; 
            color: #1e293b; font-size: 11px; font-weight: 700; flex-shrink: 0;
        }
        
        .avatar-purple { background-color: #e0e7ff; color: #4338ca; }
        .avatar-blue { background-color: #dbeafe; color: #1d4ed8; }
        .avatar-green { background-color: #dcfce7; color: #15803d; }
        .avatar-lightblue { background-color: #e0f2fe; color: #0369a1; }
        .avatar-lightpurple { background-color: #ede9fe; color: #6d28d9; }

        .table-footer { font-size: 12px; color: #94a3b8; }

    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo-box">
            <img src="<?php echo e(asset('images/sisehat_logo.svg')); ?>" alt="SiSehat" class="logo-main" onerror="this.style.display='none'; this.insertAdjacentHTML('afterend', '<h2 style=\'color:#0d47a1; font-weight:900;\'>SISEHAT</h2>');">
        </div>
        
        <?php if(auth()->user()->role !== 'employee'): ?>
        <button class="btn-primary-custom" onclick="window.location='<?php echo e(route('dashboard.tambah-umkm')); ?>'">+ Tambahkan UMKM Anda</button>
        <?php endif; ?>
        <div class="sidebar-divider"></div>
        
        <ul class="nav-list">
            <li class="nav-item" onclick="window.location='<?php echo e(route('dashboard')); ?>'">
                <img src="<?php echo e(asset('images/Beranda_logo.svg')); ?>" class="nav-icon" onerror="this.src='https://cdn-icons-png.flaticon.com/512/25/25694.png'">
                <span>Beranda</span>
            </li>
            <li class="nav-item" onclick="window.location='<?php echo e(route('dashboard.asesmen')); ?>'">
                <img src="<?php echo e(asset('images/Asesmen_Organisasi_logo.svg')); ?>" class="nav-icon" onerror="this.src='https://cdn-icons-png.flaticon.com/512/1161/1161388.png'">
                <span>Asesmen Organisasi</span>
            </li>
            <li class="nav-item" onclick="window.location='<?php echo e(route('dashboard.faktor')); ?>'">
                <img src="<?php echo e(asset('images/6_Faktor_Penilaian_logo.svg')); ?>" class="nav-icon" onerror="this.src='https://cdn-icons-png.flaticon.com/512/138/138439.png'">
                <span>6 Faktor Penilaian</span>
            </li>
            <li class="nav-item" onclick="window.location='<?php echo e(route('dashboard.rekomendasi')); ?>'">
                <img src="<?php echo e(asset('images/Rekomendasi_logo.svg')); ?>" class="nav-icon" onerror="this.src='https://cdn-icons-png.flaticon.com/512/151/151300.png'">
                <span>Rekomendasi</span>
            </li>
            <?php if(auth()->user()->role !== 'employee'): ?>
            <li class="nav-item" onclick="window.location='<?php echo e(route('dashboard.tambah-umkm')); ?>'">
                <img src="<?php echo e(asset('images/Tambah_Data_UMKM_logo.svg')); ?>" class="nav-icon" onerror="this.src='https://cdn-icons-png.flaticon.com/512/2990/2990315.png'">
                <span>Tambah Data UMKM</span>
            </li>
            <?php endif; ?>
             <li class="nav-item" onclick="window.location='<?php echo e(route('dashboard.tambah-karyawan')); ?>'">
                <img src="<?php echo e(asset('images/Tambah_Data_Karyawan_logo.svg')); ?>" class="nav-icon" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3135/3135715.png'">
                <span>Tambah Data Karyawan</span>
            </li>
            <?php if(auth()->user()->role !== 'employee'): ?>
            <li class="nav-item active" onclick="window.location='<?php echo e(route('dashboard.manajemen-umkm')); ?>'">
                <img src="<?php echo e(asset('images/Manajemen_UMKM_logo.svg')); ?>" class="nav-icon" onerror="this.src='https://cdn-icons-png.flaticon.com/512/104/104646.png'">
                <span>Manajemen UMKM</span>
            </li>
            <?php endif; ?>
        </ul>

        <div class="profile-card">
            <div class="avatar-sidebar">
                <img src="https://i.pravatar.cc/150?u=<?php echo e(auth()->user()->id ?? 1); ?>" alt="Avatar">
            </div>
            <div class="profile-info">
                <h4><?php echo e(auth()->user()->name ?? 'Riski'); ?></h4>
                <p>Pemilik UMKM</p>
            </div>
        </div>
    </div>

    <div class="content-area">
        <div class="page-header-flex">
            <div class="page-header" style="margin-bottom: 0;">
                <h1>Daftar Karyawan: <?php echo e($umkm->nama_umkm); ?></h1>
                <p>Manajemen profil dan akses karyawan untuk unit usaha ini.</p>
            </div>
            <a href="<?php echo e(route('dashboard.tambah-karyawan')); ?>" class="btn-add-karyawan">
                + Tambah Karyawan Baru
            </a>
        </div>

        <div class="table-card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width: 35%">NAMA LENGKAP</th>
                        <th style="width: 25%; text-align: center;">PASSWORD</th>
                        <th style="width: 25%; text-align: center;">JENIS KELAMIN</th>
                        <th style="width: 15%; text-align: center;">KATEGORI USIA</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="karyawan-name-cell">
                                <div class="karyawan-avatar <?php echo e(['avatar-purple', 'avatar-blue', 'avatar-green', 'avatar-lightblue', 'avatar-lightpurple'][($loop->index % 5)]); ?>">
                                    <?php echo e(strtoupper(substr($k->nama_user, 0, 2))); ?>

                                </div>
                                <?php echo e($k->nama_user); ?>

                            </div>
                        </td>
                        <td style="text-align: center; color: #94a3b8; font-size: 12px;">******** (Encrypted)</td>
                        <td style="text-align: center; color: #475569; font-weight: 500;">
                            <?php echo e($k->gender == 2 ? 'Laki-laki' : ($k->gender == 1 ? 'Perempuan' : '-')); ?>

                        </td>
                        <td style="text-align: center; color: #475569; font-weight: 500;">
                            <?php if($k->age == 1): ?> < 30 Tahun
                            <?php elseif($k->age == 2): ?> 30 - 40 Tahun
                            <?php elseif($k->age == 3): ?> > 40 Tahun
                            <?php else: ?> - <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" style="text-align: center; padding: 40px; color: #94a3b8;">
                            Belum ada karyawan terdaftar di UMKM ini.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="table-footer">
                Menampilkan <?php echo e($karyawan->count()); ?> karyawan
            </div>
        </div>

    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\sisehat\sisehat\sisehat\resources\views/manajemen-karyawan.blade.php ENDPATH**/ ?>