<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Ringkasan Asesmen</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 10px; color: #1e293b; }
        h1 { font-size: 16px; margin: 0 0 4px 0; color: #0f172a; }
        .meta { font-size: 9px; color: #64748b; margin-bottom: 16px; }
        table { width: 100%; border-collapse: collapse; margin-top: 8px; }
        th { background: #e2e8f0; color: #0f172a; text-align: left; padding: 6px 8px; border: 1px solid #cbd5e1; font-size: 9px; }
        td { padding: 6px 8px; border: 1px solid #e2e8f0; vertical-align: top; }
        td.q { width: 62%; }
        td.a { width: 38%; }
        tr:nth-child(even) td { background: #f8fafc; }
        .footer { margin-top: 14px; font-size: 8px; color: #94a3b8; }
    </style>
</head>
<body>
    <h1>Ringkasan Jawaban Asesmen Organisasi</h1>
    <div class="meta">
        Nama: <strong><?php echo e($nama); ?></strong> &nbsp;|&nbsp; Peran: <strong><?php echo e($peran); ?></strong><br>
        Tanggal cetak: <?php echo e($tanggalCetak); ?> &nbsp;|&nbsp; Status asesmen: <strong><?php echo e($statusAsesmen); ?></strong>
    </div>

    <table>
        <thead>
            <tr>
                <th class="q">Pertanyaan</th>
                <th class="a">Jawaban</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="q"><?php echo e($r['id']); ?> — <?php echo e($r['pertanyaan']); ?></td>
                <td class="a"><?php echo e($r['jawaban']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <p class="footer">Dokumen ini dihasilkan otomatis oleh SiSehat. Jawaban mencerminkan data terakhir yang tersimpan pada asesmen UMKM terkait.</p>
</body>
</html>
<?php /**PATH C:\laragon\www\sisehat\sisehat\sisehat\resources\views/pdf/asesmen-ringkasan.blade.php ENDPATH**/ ?>