<?php
    $role = auth()->user()?->role;
    $label = match ($role) {
        'employee' => 'Karyawan',
        'admin' => 'Admin',
        default => 'Pemilik UMKM',
    };
?>
<p><?php echo e($label); ?></p>
<?php /**PATH C:\laragon\www\sisehat\sisehat\sisehat\resources\views/components/sidebar-role-subtitle.blade.php ENDPATH**/ ?>